Project Mobile Computing for the classes in HSB Bremen
